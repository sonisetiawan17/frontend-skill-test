import React from 'react';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import AllAboutBitcoinPage from './pages/Lists/AllAboutBitcoin';
import BBCNewsPages from './pages/Lists/BBCNews';
import DetailAboutBitcoin from './pages/Details/DetailAboutBitcoin';
import DetailBBCNews from './pages/Details/DetailBBCNews';
import DetailTopHeadlines from './pages/Details/DetailTopHeadlines';
import HomePage from './pages/Home';
import TopHeadlinesPage from './pages/Lists/TopHeadlines';

import Root from './routes/Root';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Root />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'top-headlines', element: <TopHeadlinesPage /> },
      { path: 'top-headlines/:newsTitle', element: <DetailTopHeadlines /> },
      { path: 'bbc-news', element: <BBCNewsPages /> },
      { path: 'bbc-news/:newsTitle', element: <DetailBBCNews /> },
      { path: 'bitcoin', element: <AllAboutBitcoinPage /> },
      { path: 'bitcoin/:newsTitle', element: <DetailAboutBitcoin /> },
    ],
  },
]);

const App: React.FC = () => {
  return (
    <div>
      <RouterProvider router={router} />
    </div>
  );
};

export default App;
