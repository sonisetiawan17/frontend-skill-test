import React from 'react';
import { Outlet } from 'react-router-dom';
import NavbarComponent from '../components/Navbar/Navbar';

const Root = () => {
  return (
    <>
      <NavbarComponent />
      <main>
        <Outlet />
      </main>
    </>
  );
};

export default Root;
