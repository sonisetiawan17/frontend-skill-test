import axios from 'axios';

const baseUrl = process.env.REACT_APP_BASE_URL;
const apiKey = process.env.REACT_APP_API_KEY;

export const getTopHeadlinesNews = async () => {
  const response = await axios.get(
    `${baseUrl}/top-headlines?country=us&apiKey=${apiKey}`
  );
  return response.data.articles;
};

export const getBBCNews = async () => {
  const response = await axios.get(
    `${baseUrl}/top-headlines?sources=bbc-news&apiKey=${apiKey}`
  );
  return response.data.articles;
};

export const getAllAboutBitcoinNews = async () => {
  const response = await axios.get(
    `${baseUrl}/everything?q=bitcoin&apiKey=${apiKey}`
  );
  return response.data.articles;
};
