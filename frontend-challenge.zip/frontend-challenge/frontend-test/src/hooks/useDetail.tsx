import { useRef, useState } from 'react';
import { useParams } from 'react-router-dom';

interface News {
  title: string;
  content: string;
  urlToImage: string;
  publishedAt: string;
  url: string;
  source: {
    name: string;
  };
}

export const useDetail = () => {
  const params = useParams();
  const [news, setNews] = useState<News[] | null>(null);
  const strict = useRef<Boolean>(true);

  const articles = news && news.find((item) => item.title === params.newsTitle);

  const date: string = articles?.publishedAt ?? '';

  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  };

  const publishedAt = new Date(date).toLocaleDateString('en-US', options);

  return { news, setNews, strict, publishedAt, articles, date };
};
