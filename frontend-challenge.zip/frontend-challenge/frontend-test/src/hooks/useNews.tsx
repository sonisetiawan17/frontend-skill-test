import { useRef, useState } from 'react';

interface News {
  title: string;
  description: string;
  urlToImage: string;
}

export const useNews = () => {
  const [news, setNews] = useState<News[] | null>(null);
  const [error, setError] = useState<Error | null>(null);

  const strict = useRef<Boolean>(true);

  return { news, setNews, error, setError, strict };
};
