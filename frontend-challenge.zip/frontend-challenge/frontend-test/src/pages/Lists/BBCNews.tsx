import React, { useEffect } from 'react';
import { Col, Row } from 'antd';
import { useNews } from '../../hooks/useNews';
import { getBBCNews } from '../../utils/api';
import CardComponent from '../../components/Card/Card';
import { Link } from 'react-router-dom';

const BBCNewsPage: React.FC = () => {
  const bbcNews = useNews();

  useEffect(() => {
    if (bbcNews.strict.current) {
      bbcNews.strict.current = false;
      try {
        getBBCNews().then((result) => bbcNews.setNews(result));
      } catch (error) {
        bbcNews.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [bbcNews]);

  if (bbcNews.error) {
    return <p>{bbcNews.error.message}</p>;
  }

  return (
    <>
      {bbcNews.news ? (
        <div>
          <h3>Top Headlines from BBC News</h3>
          <Row gutter={[16, 32]}>
            {bbcNews.news &&
              bbcNews.news.slice(0, 20).map((item, key) => (
                <Col xs={12} sm={12} md={8} lg={6} key={key}>
                  <Link to={`/bbc-news/${item.title}`}>
                    <CardComponent
                      title={item.title}
                      description={`${item.description.slice(0, 60)}...`}
                      imgUrl={item.urlToImage}
                    />
                  </Link>
                </Col>
              ))}
          </Row>
        </div>
      ) : (
        <p className="loading_status">Loading...</p>
      )}
    </>
  );
};

export default BBCNewsPage;
