import React, { useEffect } from 'react';
import { Col, Row } from 'antd';
import { useNews } from '../../hooks/useNews';
import { getAllAboutBitcoinNews } from '../../utils/api';
import CardComponent from '../../components/Card/Card';
import Bitcoin from '../../assets/images/bitcoin.jpg';
import { Link } from 'react-router-dom';

const AllAboutBitcoinPage: React.FC = () => {
  const bitcoin = useNews();

  useEffect(() => {
    if (bitcoin.strict.current) {
      bitcoin.strict.current = false;
      try {
        getAllAboutBitcoinNews().then((result) => bitcoin.setNews(result));
      } catch (error) {
        bitcoin.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [bitcoin]);

  if (bitcoin.error) {
    return <p>{bitcoin.error.message}</p>;
  }

  return (
    <>
      {bitcoin.news ? (
        <div>
          <h3>All About Bitcoin</h3>
          <Row gutter={[16, 32]}>
            {bitcoin.news &&
              bitcoin.news.slice(0, 40).map((item, key) => (
                <Col xs={12} sm={12} md={8} lg={6} key={key}>
                  <Link to={`/bitcoin/${item.title}`}>
                    <CardComponent
                      title={item.title}
                      description={`${item.description.slice(0, 60)}...`}
                      imgUrl={item.urlToImage ? `${item.urlToImage}` : Bitcoin}
                    />
                  </Link>
                </Col>
              ))}
          </Row>
        </div>
      ) : (
        <p className="loading_status">Loading...</p>
      )}
    </>
  );
};

export default AllAboutBitcoinPage;
