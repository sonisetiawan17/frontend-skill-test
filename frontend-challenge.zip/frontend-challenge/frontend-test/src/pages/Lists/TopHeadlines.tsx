import React, { useEffect } from 'react';
import { Col, Row } from 'antd';
import { useNews } from '../../hooks/useNews';
import { getTopHeadlinesNews } from '../../utils/api';
import CardComponent from '../../components/Card/Card';
import { Link } from 'react-router-dom';

const TopHeadlinesPage: React.FC = () => {
  const topHeadlines = useNews();

  useEffect(() => {
    if (topHeadlines.strict.current) {
      topHeadlines.strict.current = false;
      try {
        getTopHeadlinesNews().then((result) => topHeadlines.setNews(result));
      } catch (error) {
        topHeadlines.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [topHeadlines]);

  if (topHeadlines.error) {
    return <p>{topHeadlines.error.message}</p>;
  }

  return (
    <>
      {topHeadlines.news ? (
        <div>
          <h3>Top Headlines from the US</h3>
          <Row gutter={[16, 32]}>
            {topHeadlines.news &&
              topHeadlines.news.slice(0, 20).map((item, key) => (
                <Col xs={12} sm={12} md={8} lg={6} key={key}>
                  <Link to={`/top-headlines/${item.title}`}>
                    <CardComponent
                      title={item.title}
                      description={`${item.description.slice(0, 60)}...`}
                      imgUrl={item.urlToImage}
                    />
                  </Link>
                </Col>
              ))}
          </Row>
        </div>
      ) : (
        <p className="loading_status">Loading...</p>
      )}
    </>
  );
};

export default TopHeadlinesPage;
