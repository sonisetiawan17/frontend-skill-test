import React from 'react';
import AllAboutBitcoin from '../partials/AllAboutBitcoin';
import TopBBCNews from '../partials/TopBBCNews';
import TopHeadlines from '../partials/TopHeadlinesUS';

const HomePage = () => {
  return (
    <>
      <TopHeadlines />
      <TopBBCNews />
      <AllAboutBitcoin />
    </>
  );
};

export default HomePage;
