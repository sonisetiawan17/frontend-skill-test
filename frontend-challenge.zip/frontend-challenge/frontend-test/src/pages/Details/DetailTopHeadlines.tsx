import React, { useEffect } from 'react';
import ButtonComponent from '../../components/Button/Button';
import { Link } from 'react-router-dom';
import { getTopHeadlinesNews } from '../../utils/api';
import { useDetail } from '../../hooks/useDetail';
import '../../scss/main.scss';

const DetailTopHeadlines: React.FC = () => {
  const newsDetail = useDetail();

  useEffect(() => {
    if (newsDetail.strict.current) {
      newsDetail.strict.current = false;
      getTopHeadlinesNews().then((result) => newsDetail.setNews(result));
    }
  }, [newsDetail]);

  return (
    <>
      {newsDetail.articles ? (
        <div className="news_detail">
          <div className="news_title">
            <h2>{newsDetail.articles && newsDetail.articles.title}</h2>
            <p>
              Published at : {newsDetail.publishedAt} by{' '}
              <span>
                {newsDetail.articles && newsDetail.articles.source.name}
              </span>
            </p>
          </div>
          <div className="news_image">
            {newsDetail.articles && newsDetail.articles.urlToImage && (
              <img
                src={newsDetail.articles.urlToImage}
                alt={newsDetail.articles.title}
              />
            )}
          </div>
          <div className="news_content">
            <p>{newsDetail.articles && newsDetail.articles.content}</p>
            <Link
              to={`${newsDetail.articles && newsDetail.articles.url}`}
              target="_blank"
            >
              <ButtonComponent>See article detail</ButtonComponent>
            </Link>
          </div>
        </div>
      ) : (
        <p className="loading_status">Loading...</p>
      )}
    </>
  );
};

export default DetailTopHeadlines;
