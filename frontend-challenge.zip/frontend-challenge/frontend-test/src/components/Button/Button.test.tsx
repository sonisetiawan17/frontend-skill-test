import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import ButtonComponent from './Button';

describe('ButtonComponent', () => {
  test('calls onClick when clicked', () => {
    const handleClick = jest.fn();
    render(<ButtonComponent onClick={handleClick}>Click Me</ButtonComponent>);
    const button = screen.getByRole('button');
    fireEvent.click(button);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
