import React from 'react';
import { Button } from 'antd';
import { ButtonProps } from 'antd/es/button';
import '../../scss/main.scss';

interface Props extends ButtonProps {}

const ButtonComponent: React.FC<Props> = ({ ...props }: Props) => (
  <Button className="btn" {...props} />
);

export default ButtonComponent;
