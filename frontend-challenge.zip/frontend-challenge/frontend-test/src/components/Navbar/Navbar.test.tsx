import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { render, screen } from '@testing-library/react';
import NavbarComponent from './Navbar';

describe('NavbarComponent', () => {
  test('should render the title correctly', () => {
    render(
      <BrowserRouter>
        <NavbarComponent />
      </BrowserRouter>
    );
    const titleElement = screen.getByText(/NEWS API/i);
    expect(titleElement).toBeInTheDocument();
  });
});
