import React from 'react';
import { Link } from 'react-router-dom';
import '../../scss/main.scss';

const NavbarComponent: React.FC = () => {
  return (
    <nav>
      <div className="nav_title">
        <Link to="/">
          <h2>NEWS API</h2>
        </Link>
      </div>
    </nav>
  );
};

export default NavbarComponent;
