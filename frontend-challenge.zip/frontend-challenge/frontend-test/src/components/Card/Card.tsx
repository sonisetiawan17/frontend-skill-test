import React from 'react';
import { Card } from 'antd';
import '../../scss/main.scss';

const { Meta } = Card;

interface CardProps {
  title: string;
  description: string;
  imgUrl: string;
}

const CardComponent: React.FC<CardProps> = ({ title, description, imgUrl }) => (
  <>
    <Card
      className="card-content"
      cover={
        <img
          alt={title}
          src={imgUrl}
          style={{ height: '200px', objectFit: 'cover' }}
        />
      }
    >
      <Meta className="card_title" title={title} description={description} />
    </Card>
  </>
);

export default CardComponent;
