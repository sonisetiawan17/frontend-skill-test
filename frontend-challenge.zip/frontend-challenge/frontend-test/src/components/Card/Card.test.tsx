import React from 'react';
import { render, screen } from '@testing-library/react';
import CardComponent from './Card';

describe('Card Component', () => {
  const props = {
    title: 'Title',
    description: 'Description',
    imgUrl:
      'https://s.yimg.com/os/creatr-uploaded-images/2023-03/d485be51-c12c-11ed-9f3f-148c8b08a5d9',
  };

  test('should render card title and description', () => {
    render(<CardComponent {...props} />);
    const titleElement = screen.getByText(props.title);
    const descriptionElement = screen.getByText(props.description);
    expect(titleElement).toBeInTheDocument();
    expect(descriptionElement).toBeInTheDocument();
  });

  test('should render card image with correct src and alt text', () => {
    render(<CardComponent {...props} />);
    const imageElement = screen.getByAltText(props.title);
    expect(imageElement).toBeInTheDocument();
    expect(imageElement).toHaveAttribute('src', props.imgUrl);
  });
});
