import React, { useEffect } from 'react';
import { Col, Row } from 'antd';
import { Link } from 'react-router-dom';
import { useNews } from '../hooks/useNews';
import { getAllAboutBitcoinNews } from '../utils/api';
import Bitcoin from '../assets/images/bitcoin.jpg';
import CardComponent from '../components/Card/Card';

const AllAboutBitcoin: React.FC = () => {
  const bitcoin = useNews();

  useEffect(() => {
    if (bitcoin.strict.current) {
      bitcoin.strict.current = false;
      try {
        getAllAboutBitcoinNews().then((result) => bitcoin.setNews(result));
      } catch (error) {
        bitcoin.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [bitcoin]);

  if (bitcoin.error) {
    return <p>{bitcoin.error.message}</p>;
  }

  return (
    <>
      {bitcoin.news ? (
        <div style={{ marginTop: '2rem' }}>
          <div className="news_source">
            <h3>All About Bitcoin</h3>
            <Link to="/bitcoin">
              <p>See all</p>
            </Link>
          </div>
          <div className="card">
            <Row gutter={[16, 16]}>
              {bitcoin.news &&
                bitcoin.news.slice(1, 21).map((item, key) => (
                  <Col xs={12} sm={12} md={8} lg={6} key={key}>
                    <Link to={`/bitcoin/${item.title}`}>
                      <CardComponent
                        title={item.title}
                        description={`${item.description.slice(0, 60)}...`}
                        imgUrl={item.urlToImage ? item.urlToImage : Bitcoin}
                      />
                    </Link>
                  </Col>
                ))}
            </Row>
          </div>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default AllAboutBitcoin;
