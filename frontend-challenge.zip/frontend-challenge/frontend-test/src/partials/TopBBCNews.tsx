import React, { useEffect } from 'react';
import CardComponent from '../components/Card/Card';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper';
import { Link } from 'react-router-dom';
import { useNews } from '../hooks/useNews';
import { getBBCNews } from '../utils/api';
import 'swiper/css';
import 'swiper/css/pagination';
import '../scss/main.scss';

const TopBBCNews: React.FC = () => {
  const bbcNews = useNews();

  useEffect(() => {
    if (bbcNews.strict.current) {
      bbcNews.strict.current = false;
      try {
        getBBCNews().then((result) => bbcNews.setNews(result));
      } catch (error) {
        bbcNews.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [bbcNews]);

  if (bbcNews.error) {
    return <p>{bbcNews.error.message}</p>;
  }

  return (
    <>
      {bbcNews.news ? (
        <div style={{ marginTop: '2rem' }}>
          <div className="news_source">
            <h3>Top Headlines from BBC News</h3>
            <Link to="/bbc-news">
              <p>See all</p>
            </Link>
          </div>
          <div className="card">
            <Swiper
              slidesPerView={4}
              spaceBetween={10}
              pagination={{
                clickable: true,
              }}
              modules={[Pagination]}
              breakpoints={{
                0: {
                  slidesPerView: 1.1,
                  spaceBetween: 10,
                },
                481: {
                  slidesPerView: 2.1,
                  spaceBetween: 10,
                },
                769: {
                  slidesPerView: 3,
                  spaceBetween: 10,
                },
                1025: {
                  slidesPerView: 4,
                  spaceBetween: 10,
                },
              }}
            >
              {bbcNews.news &&
                bbcNews.news.map((item, key) => (
                  <SwiperSlide key={key}>
                    <Link to={`/bbc-news/${item.title}`}>
                      <CardComponent
                        title={item.title}
                        description={`${item.description.slice(0, 60)}...`}
                        imgUrl={item.urlToImage}
                      />
                    </Link>
                  </SwiperSlide>
                ))}
            </Swiper>
          </div>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default TopBBCNews;
