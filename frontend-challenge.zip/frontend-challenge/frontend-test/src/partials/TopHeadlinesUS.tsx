import React, { useEffect } from 'react';
import CardComponent from '../components/Card/Card';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper';
import { Link } from 'react-router-dom';
import { getTopHeadlinesNews } from '../utils/api';
import { useNews } from '../hooks/useNews';
import 'swiper/css';
import 'swiper/css/pagination';

const TopHeadlines: React.FC = () => {
  const topHeadlines = useNews();

  useEffect(() => {
    if (topHeadlines.strict.current) {
      topHeadlines.strict.current = false;
      try {
        getTopHeadlinesNews().then((result) => topHeadlines.setNews(result));
      } catch (error) {
        topHeadlines.setError(new Error('Failed to fetch News Article'));
      }
    }
  }, [topHeadlines]);

  if (topHeadlines.error) {
    return <p>{topHeadlines.error.message}</p>;
  }

  return (
    <>
      {topHeadlines.news ? (
        <div>
          <div className="news_source">
            <h3>Top Headlines from the US</h3>
            <Link to="/top-headlines">
              <p>See all</p>
            </Link>
          </div>
          <div className="card">
            <Swiper
              slidesPerView={4}
              spaceBetween={10}
              pagination={{
                clickable: true,
              }}
              modules={[Pagination]}
              breakpoints={{
                0: {
                  slidesPerView: 1.1,
                  spaceBetween: 10,
                },
                481: {
                  slidesPerView: 2.1,
                  spaceBetween: 10,
                },
                769: {
                  slidesPerView: 3,
                  spaceBetween: 10,
                },
                1025: {
                  slidesPerView: 4,
                  spaceBetween: 10,
                },
              }}
            >
              {topHeadlines.news &&
                topHeadlines.news.map((item, key) => (
                  <SwiperSlide key={key}>
                    <Link to={`/top-headlines/${item.title}`}>
                      <CardComponent
                        title={item.title}
                        description={`${item.description.slice(0, 60)}...`}
                        imgUrl={item.urlToImage}
                      />
                    </Link>
                  </SwiperSlide>
                ))}
            </Swiper>
          </div>
        </div>
      ) : (
        <p className="loading_status">Please wait...</p>
      )}
    </>
  );
};

export default TopHeadlines;
