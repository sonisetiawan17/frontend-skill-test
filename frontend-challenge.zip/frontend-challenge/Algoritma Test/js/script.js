const answerElOne = document.querySelector('.answer-one');
const answerElTwo = document.querySelector('.answer-two');
const answerElThree = document.querySelector('.answer-three');
const answerElFour = document.querySelector('.answer-four');

// Soal 1
const text = 'NEGIE1';
const textToArr = text.split('');
const reverseText = textToArr.slice(0, 5).reverse();
const mergeText = reverseText.concat(textToArr[5]).join('');

const answerOne = document.createElement('p');
answerOne.textContent = mergeText;
answerElOne.appendChild(answerOne);

// Soal 2
const sentence = 'Saya sangat senang mengerjakan soal algoritma';
const sentenceToArr = sentence.split(' ');
let word = '';

for (let i = 0; i < sentenceToArr.length; i++) {
  if (sentenceToArr[i].length > word.length) {
    word = sentenceToArr[i];
  }
}

const answerTwo = document.createElement('p');
answerTwo.textContent = `${word} : ${word.length} character`;
answerElTwo.appendChild(answerTwo);

// Soal 3
const INPUT = ['xc', 'dz', 'bbb', 'dz'];
const QUERY = ['bbb', 'ac', 'dz'];
let arr = [];

for (let i = 0; i < QUERY.length; i++) {
  const words = INPUT.filter((word) => word === QUERY[i]).length;
  arr.push(words);
}

let result = `OUTPUT : [${arr.join(', ')}] karena kata '${QUERY[0]}' terdapat ${
  arr[0] != 0 ? arr[0] : 'tidak ada'
} pada INPUT, kata '${QUERY[1]}' ${
  arr[1] != 0 ? arr[1] : 'tidak ada'
} pada INPUT, dan kata '${QUERY[2]}' terdapat ${
  arr[2] != 0 ? arr[2] : 'tidak ada'
} pada INPUT`;

const answerThree = document.createElement('p');
answerThree.textContent = result;
answerElThree.appendChild(answerThree);

// Soal 4
const matrix = [
  [1, 2, 0],
  [4, 5, 6],
  [7, 8, 9],
];
let diagonal1 = 0;
let diagonal2 = 0;

for (let i = 0; i < matrix.length; i++) {
  diagonal1 += matrix[i][i];
  diagonal2 += matrix[i][matrix.length - i - 1];
}

const diagonalResult = `Result : ${diagonal1} - ${diagonal2} = ${
  diagonal1 - diagonal2
}`;

const answerFour = document.createElement('p');
answerFour.textContent = diagonalResult;
answerElFour.appendChild(answerFour);
